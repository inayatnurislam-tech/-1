"""Local Python demo server. Run: python app.py [port] [data-root]."""
import json
import os
from pathlib import Path
import re
import sqlite3
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlsplit
from uuid import uuid4
from model import analyze, card, matches

ROOT = Path(__file__).resolve().parent


class Store:
    def __init__(self, root):
        (root / 'data').mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(root / 'data' / 'challenges.sqlite3')
        self.db.execute('CREATE TABLE IF NOT EXISTS challenges (id TEXT PRIMARY KEY, payload TEXT NOT NULL)')
        demo = json.loads((ROOT / 'demo.json').read_text(encoding='utf-8'))
        self.teams = demo['teams']
        if not self.db.execute('SELECT 1 FROM challenges LIMIT 1').fetchone():
            for row in demo['challenges']: self.save(row)

    def rows(self):
        return [json.loads(row[0]) for row in self.db.execute('SELECT payload FROM challenges ORDER BY rowid')]

    def get(self, identifier):
        row = self.db.execute('SELECT payload FROM challenges WHERE id=?', (identifier,)).fetchone()
        return json.loads(row[0]) if row else None

    def save(self, row):
        with self.db:
            self.db.execute('INSERT INTO challenges VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload', (row['id'], json.dumps(row, ensure_ascii=False)))


class Invalid(Exception):
    def __init__(self, status, message): self.status, self.message = status, message


def handler(store):
    class Handler(BaseHTTPRequestHandler):
        def reply(self, status, value, content_type='application/json; charset=utf-8'):
            body = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            path = urlsplit(self.path).path
            if path == '/api/bootstrap':
                return self.reply(200, dict(challenges=store.rows(), teams=store.teams))
            files = {'/': ('index.html', 'text/html'), '/index.html': ('index.html', 'text/html'), '/app.js': ('app.js', 'application/javascript'), '/style.css': ('style.css', 'text/css'), '/favicon.svg': ('favicon.svg', 'image/svg+xml')}
            if path not in files: return self.reply(404, {'error': 'Страница не найдена'})
            name, mime = files[path]
            self.reply(200, (ROOT / 'web' / name).read_bytes(), mime + '; charset=utf-8')

        def do_POST(self):
            try:
                expected = f'http://127.0.0.1:{self.server.server_port}'
                localhost = f'http://localhost:{self.server.server_port}'
                if self.headers.get('Origin') not in (None, expected, localhost):
                    raise Invalid(403, 'Запрос с другого сайта запрещён')
                if self.headers.get('Sec-Fetch-Site') == 'cross-site': raise Invalid(403, 'Запрос с другого сайта запрещён')
                try: length = int(self.headers.get('Content-Length', '0'))
                except ValueError: raise Invalid(400, 'Некорректная длина запроса')
                if not 0 <= length <= 150000: raise Invalid(413, 'Слишком большой запрос')
                self.connection.settimeout(10)
                raw = self.rfile.read(length).decode('utf-8')
                f = {k: v[-1].strip() for k, v in parse_qs(raw, keep_blank_values=True, max_num_fields=100).items()}
                if any(len(v.encode()) > 6000 for v in f.values()): raise Invalid(400, 'Поле слишком длинное: максимум 6000 байт')
                path = urlsplit(self.path).path
                if path == '/api/analyze': result = analyze(f)
                elif path == '/api/matches': result = matches(f, store.teams)
                elif path == '/api/publish':
                    duration = f.get('a6', f.get('weeks', ''))
                    if not re.fullmatch(r'[0-9]{1,2}', duration) or not 1 <= int(duration) <= 52: raise Invalid(400, 'Срок должен быть целым числом от 1 до 52 недель')
                    if not all(f.get(k) for k in ('title', 'company', 'description')): raise Invalid(400, 'Заполните название, компанию и описание')
                    if not analyze(f)['publishable']: raise Invalid(422, 'Уточните задачу до 70% и устраните критические риски')
                    old = store.get(f.get('id', ''))
                    if f.get('id') and not old: raise Invalid(404, 'Задача не найдена')
                    for key, default in [('id', 'task-' + uuid4().hex), ('applications', ''), ('status', 'Открыт'), ('sample', '0'), ('selectedTeam', '')]:
                        f[key] = old.get(key, default) if old else default
                    result = card(f)
                    store.save(result)
                elif path in ('/api/apply', '/api/select'):
                    result = store.get(f.get('id', ''))
                    if not result: raise Invalid(404, 'Задача не найдена')
                    team = f.get('team')
                    if team not in {t['id'] for t in store.teams}: raise Invalid(400, 'Выберите команду')
                    apps = list(filter(None, result.get('applications', '').split(',')))
                    if path == '/api/select':
                        if team not in apps: raise Invalid(422, 'Команда ещё не откликнулась')
                        if result.get('selectedTeam') and result['selectedTeam'] != team: raise Invalid(409, 'Команда уже выбрана')
                        result.update(selectedTeam=team, status='Команда выбрана')
                    else:
                        if result.get('selectedTeam'): raise Invalid(409, 'Приём откликов завершён')
                        if team not in apps: apps.append(team)
                        result['applications'] = ','.join(apps)
                    store.save(result)
                else: raise Invalid(404, 'Метод не найден')
                self.reply(200, result)
            except Invalid as exc: self.reply(exc.status, {'error': exc.message})
            except (ValueError, UnicodeError): self.reply(400, {'error': 'Некорректный запрос'})
            except sqlite3.Error: self.reply(500, {'error': 'Не удалось сохранить данные'})
    return Handler


def main():
    port = int(sys.argv[1] if len(sys.argv) > 1 else os.environ.get('PORT', '8080'))
    if not 1024 <= port <= 65535: raise SystemExit('Порт: 1024–65535')
    store = Store(Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else ROOT)
    server = HTTPServer(('127.0.0.1', port), handler(store))
    print(f'AI Sana: http://127.0.0.1:{port} — остановка Ctrl+C', flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        server.server_close()
        store.db.close()


if __name__ == '__main__': main()
