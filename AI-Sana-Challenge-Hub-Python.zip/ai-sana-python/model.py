"""Explainable, deterministic demo scoring. No external AI service."""
import math


def number(value, default=4):
    try:
        return max(1, min(52, int(value)))
    except (ValueError, TypeError):
        return default


def readiness(f):
    def points(i, full, base=0):
        if not f.get(f'a{i}'): return base
        return (base + full) // 2 if f.get(f'u{i}') == '1' else full
    desc = len(f.get('description', '').encode()) >= 12
    values = [
        ('Проблема понятна', points(7, 14, 10) if desc else 0, 14),
        ('Целевая аудитория', points(0, 12, 4 if desc else 0), 12),
        ('Ожидаемый результат', points(2, 12, 6 if f.get('result') else 0), 12),
        ('Доступные данные', points(3, 12), 12),
        ('Реалистичный срок', points(6, 10 if number(f.get('a6')) >= 3 else 3, 8 if f.get('weeks') else 0), 10),
        ('Критерии успеха', (6 if f.get('u1') == '1' or f.get('u2') == '1' else 13) if f.get('a1') and f.get('a2') else 0, 13),
        ('Ограничения', points(4, 9), 9), ('Риски учтены', points(5, 9), 9)]
    return [dict(name=n, value=v, max=m) for n, v, m in values]


def skills(f):
    explicit = [s.strip() for s in f.get('skills', '').split(',') if s.strip()]
    return list(dict.fromkeys(explicit)) or {'Производство': ['Python', 'Data Analysis', 'Computer Vision'], 'Экология': ['Python', 'Data Analysis', 'IoT'], 'Сервис': ['Python', 'NLP', 'Web']}.get(f.get('industry'), ['Python', 'Data Analysis', 'Web', 'UX'])


def card(fields):
    f = dict(fields)
    for key, answer, default in [('users', 'a0', 'Требует уточнения'), ('goal', 'a2', f.get('result', '')), ('data', 'a3', 'Наличие данных не подтверждено'), ('constraints', 'a4', 'Нужно согласовать источники данных'), ('privacy', 'a5', 'Обработка персональных данных не согласована'), ('owner', 'a7', f.get('contact', ''))]:
        f[key] = f.get(answer, default)
    f.update(deadline=f.get('a6', f.get('weeks', '4')) + ' нед.', criteria=f.get('a1', 'Исходный показатель не измерен') + ' → ' + f.get('a2', 'Целевой показатель не задан'), skills=','.join(skills(f)), score=str(sum(c['value'] for c in readiness(f))))
    f.setdefault('importance', 'Снижение потерь времени и ресурсов; эффект подтвердить измерениями во время пилота.')
    f.setdefault('format', 'Веб-прототип, панель показателей и отчёт о пилотном тестировании')
    f.setdefault('difficulty', 'Средняя')
    return f


def analyze(f):
    criteria = readiness(f)
    score = sum(c['value'] for c in criteria)
    camera, privacy = f.get('a4', '').lower(), f.get('a5', '').lower()
    unsafe = ('распознавание лиц' in camera and 'без распознавания' not in camera) or ('без согласия' in privacy and 'не ' not in privacy)
    short = number(f.get('a6', f.get('weeks'))) < 3
    uncertain = any(f.get(f'u{i}') == '1' for i in range(8))
    reviews = [
        dict(role='Студент', status='ready' if f.get('a2') else 'warning', text='Есть цель и ожидаемый результат' if f.get('a2') else 'Результат пока не определён', recommendation='Согласуйте состав прототипа до старта.'),
        dict(role='Бизнес', status='ready' if f.get('a1') and f.get('a2') else 'warning', text='Пользу нужно сравнивать с исходным показателем', recommendation='Проведите замер до и после пилота.'),
        dict(role='Технический эксперт', status='critical' if short else 'warning' if score < 70 or uncertain else 'ready', text='Срок меньше трёх недель: сократите объём' if short else 'Требуется проверка качества данных', recommendation='Ограничьте MVP одной площадкой и одним главным сценарием.'),
        dict(role='Эксперт по безопасности', status='critical' if unsafe else 'warning', text='Распознавание лиц или данные без согласия: публикация заблокирована' if unsafe else 'Проверьте ограничения на использование данных', recommendation='Используйте обезличенные или синтетические данные для демо.')]
    return dict(score=score, criteria=criteria, reviews=reviews, publishable=score >= 70 and not short and not unsafe, card=card(f))


def matches(f, teams):
    def match(t, designer=False):
        need = skills(f)
        own = t['skills'] + (['UX'] if designer else [])
        roles = t['roles'] + (['Дизайнер'] if designer else [])
        required = ['Разработчик', 'Аналитик', 'Дизайнер']
        similar = {'qazaq': 2, 'steppe': 1, 'nomads': 2, 'sana': 1, 'bolashaq': 0}[t['id']]
        values = [math.floor(45 * sum(s in own for s in need) / len(need) + .5), 5 * sum(r in roles for r in required), 15 if similar >= 2 else 8 if similar else 0, 10 if t['weeks'] >= number(f.get('a6', f.get('weeks'))) else 0, 10 if t['industry'] == f.get('industry') else 0, 5 if len(t['members']) + designer >= 3 else 2]
        labels = ['Навыки', 'Роли', 'Похожие проекты', 'Доступность', 'Отрасль', 'Размер команды']
        return dict(teamId=t['id'], score=sum(values), breakdown={k: f'{v} / {m}' for k, v, m in zip(labels, values, [45, 15, 15, 10, 10, 5])}, missing=[s for s in need if s not in own] + [r for r in required if r not in roles])
    return sorted([dict(match(t), withDesigner=match(t, True)['score']) for t in teams], key=lambda m: -m['score'])
