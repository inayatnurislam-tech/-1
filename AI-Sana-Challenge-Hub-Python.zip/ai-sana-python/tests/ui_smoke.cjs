// Runs the real UI functions against the Python API. No browser/layout emulation.
// Start python app.py first. Node 18+ required only for this optional test.
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const nodes = new Map();
function node(sel) {
  if (!nodes.has(sel)) nodes.set(sel, {innerHTML:'',textContent:'',value:'',classList:{add(){},remove(){}},addEventListener(){}});
  return nodes.get(sel);
}
const storage = new Map();
const context = vm.createContext({
  document:{querySelector:node},
  window:{scrollTo(){},addEventListener(){}},
  location:{hash:'#home'},
  localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},
  fetch:(url,options)=>fetch('http://127.0.0.1:8080'+url,options),
  URLSearchParams,AbortController,console,setTimeout,clearTimeout,
});
vm.runInContext(fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8'),context);
(async()=>{
  await new Promise(r=>setTimeout(r,200));
  await vm.runInContext('refresh()',context);
  vm.runInContext('draft=demoDraft(); step=0;',context);
  await vm.runInContext('api("analyze",draft).then(a=>analysis=a)',context);
  assert.equal(vm.runInContext('analysis.score',context),28);
  for(let i=0;i<8;i++){
    node('#answer').value=vm.runInContext('questions[step][1][0]',context);
    await vm.runInContext('answer(false)',context);
  }
  assert.equal(vm.runInContext('analysis.score',context),91);
  for(const page of ['home','create','analysis','chat','twin','card','edit-card','catalog','teams','analytics','match','task/demo-1']){
    context.location.hash='#'+page;
    await vm.runInContext('render()',context);
    const html=node('#app').innerHTML;
    assert.ok(html.length>300,page);
    assert.ok(!html.includes('Не удалось загрузить страницу'),page);
  }
  vm.runInContext('draft.title="<img src=x onerror=alert(1)>"',context);
  assert.ok(vm.runInContext('draftCard()',context).includes('&lt;img'));
  assert.ok(!vm.runInContext('draftCard()',context).includes('<img src=x'));
  vm.runInContext('draft=demoDraft();step=0;',context);
  await vm.runInContext('api("analyze",draft).then(a=>analysis=a)',context);
  for(let i=0;i<8;i++)await vm.runInContext('answer(true)',context);
  assert.ok(vm.runInContext('analysis.score',context)<70);
  assert.equal(vm.runInContext('analysis.publishable',context),false);
  console.log('UI logic smoke passed: all routes, answers 28→91, assumptions, HTML escaping. Browser layout not tested.');
})().catch(e=>{console.error(e);process.exitCode=1});
