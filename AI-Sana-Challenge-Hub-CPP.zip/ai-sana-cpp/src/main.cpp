#include "http.hpp"
#include "demo.hpp"
#include <chrono>
#include <cstdlib>
using namespace sana;
int main(int argc,char** argv){try{
 int port=8080;const char* env=std::getenv("PORT");if(env)port=std::stoi(env);if(argc>1)port=std::stoi(argv[1]);if(port<1024||port>65535)throw std::runtime_error("Port must be 1024..65535");
 std::filesystem::path root=argc>2?argv[2]:".";if(!std::filesystem::exists(root/"web/index.html"))throw std::runtime_error("Run from project root, or pass root as second argument.");std::filesystem::create_directories(root/"data");auto db=root/"data/challenges.db";
 std::vector<Fields> records=seeds();if(std::filesystem::exists(db)){records.clear();std::istringstream in(readFile(db));std::string line;while(std::getline(in,line)){auto f=parse(line);if(get(f,"id").empty())throw std::runtime_error("Invalid database. Restore data/challenges.db from backup.");records.push_back(f);}}
 auto save=[&](const std::vector<Fields>& next){auto tmp=db;tmp+=".tmp";{std::ofstream out(tmp,std::ios::binary);if(!out)throw std::runtime_error("Cannot save");for(auto& f:next)out<<form(f)<<'\n';out.flush();if(!out)throw std::runtime_error("Cannot save");}
#ifdef _WIN32
 auto backup=db;backup+=".bak";if(std::filesystem::exists(db)){std::filesystem::copy_file(db,backup,std::filesystem::copy_options::overwrite_existing);std::filesystem::remove(db);}
#endif
 std::filesystem::rename(tmp,db);};
 serve(port,[&](const Request& req)->Response{
 auto path=req.path.substr(0,req.path.find('?'));
 if(req.method=="GET"&&path=="/api/bootstrap"){std::string s="{\"challenges\":[";for(auto& f:records){if(s.back()!='[')s+=",";s+=json(card(f));}return {200,s+"],\"teams\":"+teamsJson()+"}"};}
 if(req.method=="POST"&&path.rfind("/api/",0)==0){auto f=parse(req.body);for(auto& p:f)if(p.second.size()>6000)return error(400,"Поле слишком длинное: максимум 6000 байт");
 if(path=="/api/analyze")return {200,analysisJson(f)};
 if(path=="/api/matches")return {200,matchesJson(f)};
 if(path=="/api/publish"){
 auto duration=get(f,"a6",get(f,"weeks"));
 if(duration.empty()||duration.find_first_not_of("0123456789")!=std::string::npos||duration.size()>2||std::stoi(duration)<1||std::stoi(duration)>52)return error(400,"Срок должен быть целым числом от 1 до 52 недель");
 if(get(f,"title").empty()||get(f,"company").empty()||get(f,"description").empty())return error(400,"Заполните название, компанию и описание");
 if(!publishable(f))return error(422,"Уточните задачу до 70% и устраните критические риски");
 auto next=records;auto id=get(f,"id");auto it=std::find_if(next.begin(),next.end(),[&](auto& x){return get(x,"id")==id;});
 if(it!=next.end()){f["applications"]=get(*it,"applications");f["status"]=get(*it,"status");f["sample"]=get(*it,"sample");*it=card(f);}else{f["id"]="task-"+std::to_string(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now().time_since_epoch()).count());f["status"]="Открыт";f["sample"]="0";f["applications"]="";f=card(f);next.push_back(f);}try{save(next);}catch(...){return error(500,"Не удалось сохранить задачу. Проверьте доступ к папке data.");}records=std::move(next);return {200,json(f)};}
 if(path=="/api/apply"){
 auto next=records;auto it=std::find_if(next.begin(),next.end(),[&](auto& x){return get(x,"id")==get(f,"id");});if(it==next.end())return error(404,"Задача не найдена");auto team=get(f,"team");bool exists=false;for(auto& t:teams())exists|=t.id==team;if(!exists)return error(400,"Выберите команду");auto apps=split(get(*it,"applications"));if(std::find(apps.begin(),apps.end(),team)==apps.end()){apps.push_back(team);(*it)["applications"]="";for(auto& a:apps){if(!(*it)["applications"].empty())(*it)["applications"]+=",";(*it)["applications"]+=a;}}
 auto result=*it;try{save(next);}catch(...){return error(500,"Не удалось сохранить отклик");}records=std::move(next);return {200,json(result)};}
 return error(404,"Метод не найден");}
 if(req.method!="GET")return error(405,"Метод не поддерживается");
 static const std::map<std::string,std::pair<std::string,std::string>> files={{"/",{"index.html","text/html; charset=utf-8"}},{"/index.html",{"index.html","text/html; charset=utf-8"}},{"/app.js",{"app.js","application/javascript; charset=utf-8"}},{"/style.css",{"style.css","text/css; charset=utf-8"}},{"/favicon.svg",{"favicon.svg","image/svg+xml"}}};auto it=files.find(path);if(it==files.end())return error(404,"Страница не найдена");return {200,readFile(root/"web"/it->second.first),it->second.second};
 });}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
