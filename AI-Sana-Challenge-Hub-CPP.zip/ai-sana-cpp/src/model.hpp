#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cctype>
#include <map>
#include <sstream>
#include <string>
#include <vector>
namespace sana {
using Fields=std::map<std::string,std::string>;
inline std::string get(const Fields& f,const std::string& k,const std::string& d=""){auto i=f.find(k);return i==f.end()?d:i->second;}
inline std::string quote(const std::string& s){std::string r="\"";for(unsigned char c:s){if(c=='"'||c=='\\'){r+='\\';r+=char(c);}else if(c=='\n')r+="\\n";else if(c=='\r')r+="\\r";else if(c=='\t')r+="\\t";else if(c<32){const char* h="0123456789abcdef";r+="\\u00";r+=h[c>>4];r+=h[c&15];}else r+=char(c);}return r+'"';}
inline std::string json(const Fields& f){std::string r="{";for(auto& p:f){if(r.size()>1)r+=",";r+=quote(p.first)+":"+quote(p.second);}return r+"}";}
inline std::string strings(const std::vector<std::string>& v){std::string r="[";for(auto& s:v){if(r.size()>1)r+=",";r+=quote(s);}return r+"]";}
inline std::vector<std::string> split(const std::string& s,char delim=','){std::vector<std::string> r;std::istringstream in(s);std::string x;while(std::getline(in,x,delim)){auto start=x.find_first_not_of(" \t\r\n");if(start!=std::string::npos)r.push_back(x.substr(start,x.find_last_not_of(" \t\r\n")-start+1));}return r;}
inline bool has(const std::string& s,const std::string& q){return s.find(q)!=std::string::npos;}
inline int number(const std::string& s,int fallback=4){try{return std::clamp(std::stoi(s),1,52);}catch(...){return fallback;}}
struct ChallengeAnswer{std::string text;bool assumed=false;};
struct ReadinessCriterion{std::string name;int value,max;};
struct ReadinessScore{int total=0;std::vector<ReadinessCriterion> criteria;};
struct DigitalTwinReview{std::string role,status,text,recommendation;};
struct Organization{std::string name,industry,contact;};
struct Challenge{std::string id;Fields fields;};
struct TeamMember{std::string name,role;};
struct Team{std::string id,name,university,industry,project,experience;std::vector<std::string> skills,roles;std::vector<TeamMember> members;int weeks,similar;};
struct TeamMatch{std::string teamId;int score;Fields breakdown;std::vector<std::string> missing;};
struct Application{std::string challengeId,teamId;};
struct AnalyticsMetric{std::string label;int value;};
inline const std::vector<Team>& teams();
inline ReadinessScore readiness(const Fields& f){
 auto answered=[&](int i){return !get(f,"a"+std::to_string(i)).empty();};
 auto points=[&](int i,int full,int base){if(!answered(i))return base;return get(f,"u"+std::to_string(i))=="1"?(base+full)/2:full;};
 bool desc=get(f,"description").size()>=12;
 ReadinessScore r; r.criteria={
 {"Проблема понятна",desc?points(7,14,10):0,14},
 {"Целевая аудитория",points(0,12,desc?4:0),12},
 {"Ожидаемый результат",points(2,12,get(f,"result").empty()?0:6),12},
 {"Доступные данные",points(3,12,0),12},
 {"Реалистичный срок",points(6,number(get(f,"a6"))>=3?10:3,get(f,"weeks").empty()?0:8),10},
 {"Критерии успеха",answered(1)&&answered(2)?(get(f,"u1")=="1"||get(f,"u2")=="1"?6:13):0,13},
 {"Ограничения",points(4,9,0),9},{"Риски учтены",points(5,9,0),9}};
 for(auto& c:r.criteria)r.total+=c.value;
 // Nine points remain reserved for external validation of data and baseline.
 return r;
}
inline std::vector<DigitalTwinReview> review(const Fields& f){
 auto r=readiness(f);std::string privacy=get(f,"a5"),camera=get(f,"a4");
 bool faces=(has(camera,"распознавание лиц")||has(camera,"Распознавание лиц"))&&!has(camera,"без распознавания")&&!has(camera,"Без распознавания");
 bool unsafe=faces||(has(privacy,"без согласия")&&!has(privacy,"не "));
 bool uncertain=false;for(int i=0;i<8;i++)uncertain|=get(f,"u"+std::to_string(i))=="1";
 return {{"Студент",get(f,"a2").empty()?"warning":"ready",get(f,"a2").empty()?"Результат пока не определён":"Есть цель и ожидаемый результат","Согласуйте состав прототипа до старта."},
 {"Бизнес",get(f,"a1").empty()||get(f,"a2").empty()?"warning":"ready","Пользу нужно сравнивать с исходным показателем","Проведите замер до и после пилота; подтвердите критерии с заказчиком."},
 {"Технический эксперт",number(get(f,"a6",get(f,"weeks")))<3?"critical":r.total<70||uncertain?"warning":"ready",number(get(f,"a6",get(f,"weeks")))<3?"Срок меньше трёх недель: сократите объём":"Оценка предварительная: требуется проверка качества данных","Ограничьте MVP одной площадкой и одним главным сценарием."},
 {"Эксперт по безопасности",unsafe?"critical":"warning",unsafe?"Распознавание лиц или данные без согласия: публикация заблокирована":"Использование камер может затрагивать персональные данные","Для MVP используйте обезличенный подсчёт людей без распознавания лиц. Не загружайте реальные персональные данные в демо."}};
}
inline bool publishable(const Fields& f){if(readiness(f).total<70)return false;for(auto& r:review(f))if(r.status=="critical")return false;return true;}
inline std::vector<std::string> skills(const Fields& f){auto s=get(f,"skills");if(!s.empty()){auto parsed=split(s);if(!parsed.empty())return parsed;}auto industry=get(f,"industry");if(industry=="Производство")return {"Python","Data Analysis","Computer Vision"};if(industry=="Экология")return {"Python","Data Analysis","IoT"};if(industry=="Сервис")return {"Python","NLP","Web"};return {"Python","Data Analysis","Web","UX"};}
inline TeamMatch match(const Fields& f,const Team& t,bool addDesigner=false){auto need=skills(f);auto own=t.skills;auto roles=t.roles;if(addDesigner){own.push_back("UX");roles.push_back("Дизайнер");}int count=0;std::vector<std::string> missing;for(auto& s:need){if(std::find(own.begin(),own.end(),s)!=own.end())count++;else missing.push_back(s);}std::vector<std::string> required={"Разработчик","Аналитик","Дизайнер"};int rc=0;for(auto& x:required)if(std::find(roles.begin(),roles.end(),x)!=roles.end())rc++;else missing.push_back(x);
 int sk=int(std::round(45.0*count/need.size())),ro=5*rc,ex=t.similar>=2?15:t.similar==1?8:0,av=t.weeks>=number(get(f,"a6",get(f,"weeks")))?10:0,in=t.industry==get(f,"industry")?10:0,sz=t.members.size()+(addDesigner?1:0)>=3?5:2;
 return {t.id,sk+ro+ex+av+in+sz,{{"Навыки",std::to_string(sk)+" / 45"},{"Роли",std::to_string(ro)+" / 15"},{"Похожие проекты",std::to_string(ex)+" / 15"},{"Доступность",std::to_string(av)+" / 10"},{"Отрасль",std::to_string(in)+" / 10"},{"Размер команды",std::to_string(sz)+" / 5"}},missing};
}
inline Fields card(Fields f){
 f["users"]=get(f,"a0","Требует уточнения");f["goal"]=get(f,"a2",get(f,"result"));f["data"]=get(f,"a3","Наличие данных не подтверждено");f["constraints"]=get(f,"a4","Нужно согласовать источники данных");f["privacy"]=get(f,"a5","Обработка персональных данных не согласована");f["deadline"]=get(f,"a6",get(f,"weeks","4"))+" нед.";f["owner"]=get(f,"a7",get(f,"contact"));f["criteria"]=get(f,"a1","Исходный показатель не измерен")+" → "+get(f,"a2","Целевой показатель не задан");f["importance"]=get(f,"importance","Снижение потерь времени и ресурсов; эффект подтвердить измерениями во время пилота.");f["format"]=get(f,"format","Веб-прототип, панель показателей и отчёт о пилотном тестировании");f["difficulty"]=get(f,"difficulty","Средняя");auto s=skills(f);f["skills"]="";for(auto& x:s){if(!f["skills"].empty())f["skills"]+=",";f["skills"]+=x;}f["score"]=std::to_string(readiness(f).total);return f;
}
inline std::string analysisJson(const Fields& f){auto r=readiness(f);std::string out="{\"score\":"+std::to_string(r.total)+",\"publishable\":"+(publishable(f)?"true":"false")+",\"criteria\":[";for(auto& c:r.criteria){if(out.back()!='[')out+=",";out+="{\"name\":"+quote(c.name)+",\"value\":"+std::to_string(c.value)+",\"max\":"+std::to_string(c.max)+"}";}out+="],\"reviews\":[";for(auto& x:review(f)){if(out.back()!='[')out+=",";out+="{\"role\":"+quote(x.role)+",\"status\":"+quote(x.status)+",\"text\":"+quote(x.text)+",\"recommendation\":"+quote(x.recommendation)+"}";}return out+"],\"card\":"+json(card(f))+"}";}
inline std::string teamsJson(){std::string out="[";for(auto& t:teams()){if(out.size()>1)out+=",";out+="{\"id\":"+quote(t.id)+",\"name\":"+quote(t.name)+",\"university\":"+quote(t.university)+",\"industry\":"+quote(t.industry)+",\"project\":"+quote(t.project)+",\"experience\":"+quote(t.experience)+",\"weeks\":"+std::to_string(t.weeks)+",\"skills\":"+strings(t.skills)+",\"roles\":"+strings(t.roles)+",\"members\":[";for(auto& m:t.members){if(out.back()!='[')out+=",";out+=json({{"name",m.name},{"role",m.role}});}out+="]}";}return out+"]";}
inline std::string matchesJson(const Fields& f){std::vector<std::pair<TeamMatch,int>> ms;for(auto& t:teams())ms.push_back({match(f,t),match(f,t,true).score});std::sort(ms.begin(),ms.end(),[](auto& a,auto& b){return a.first.score>b.first.score;});std::string out="[";for(auto& pair:ms){auto& m=pair.first;if(out.size()>1)out+=",";out+="{\"teamId\":"+quote(m.teamId)+",\"score\":"+std::to_string(m.score)+",\"withDesigner\":"+std::to_string(pair.second)+",\"breakdown\":"+json(m.breakdown)+",\"missing\":"+strings(m.missing)+"}";}return out+"]";}
}
