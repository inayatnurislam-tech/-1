#pragma once
#include "model.hpp"
#include <cctype>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <stdexcept>
#ifdef _WIN32
#define NOMINMAX
#include <winsock2.h>
#include <ws2tcpip.h>
using Socket=SOCKET;
inline void closeSocket(Socket s){closesocket(s);}
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <signal.h>
using Socket=int;
inline void closeSocket(Socket s){close(s);}
#endif
namespace sana {
inline int hex(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;}
inline std::string decode(const std::string& s){std::string r;for(size_t i=0;i<s.size();i++){if(s[i]=='+')r+=' ';else if(s[i]=='%'&&i+2<s.size()&&hex(s[i+1])>=0&&hex(s[i+2])>=0){r+=char(16*hex(s[i+1])+hex(s[i+2]));i+=2;}else r+=s[i];}return r;}
inline std::string encode(const std::string& s){const char* h="0123456789ABCDEF";std::string r;for(unsigned char c:s){if(std::isalnum(c)||c=='-'||c=='_'||c=='.')r+=char(c);else{r+='%';r+=h[c>>4];r+=h[c&15];}}return r;}
inline Fields parse(const std::string& body){Fields f;for(auto& p:split(body,'&')){auto x=p.find('=');if(x!=std::string::npos)f[decode(p.substr(0,x))]=decode(p.substr(x+1));}return f;}
inline std::string form(const Fields& f){std::string s;for(auto& p:f){if(!s.empty())s+='&';s+=encode(p.first)+'='+encode(p.second);}return s;}
inline std::string readFile(const std::filesystem::path& p){std::ifstream in(p,std::ios::binary);if(!in)throw std::runtime_error("File unavailable");return {std::istreambuf_iterator<char>(in),std::istreambuf_iterator<char>()};}
struct Response{int status=200;std::string body,type="application/json; charset=utf-8";};
inline Response error(int status,const std::string& message){return {status,"{\"error\":"+quote(message)+"}"};}
struct Request{std::string method,path,body;std::map<std::string,std::string> headers;};
inline void sendAll(Socket c,const std::string& s){size_t pos=0;while(pos<s.size()){int n=send(c,s.data()+pos,static_cast<int>(s.size()-pos),0);if(n<=0)break;pos+=n;}}
inline void serve(int port,const std::function<Response(const Request&)>& handler){
#ifdef _WIN32
 WSADATA w;if(WSAStartup(MAKEWORD(2,2),&w)!=0)throw std::runtime_error("WSAStartup failed");
#else
 signal(SIGPIPE,SIG_IGN);
#endif
 Socket server=socket(AF_INET,SOCK_STREAM,0);int yes=1;setsockopt(server,SOL_SOCKET,SO_REUSEADDR,reinterpret_cast<const char*>(&yes),sizeof(yes));sockaddr_in addr{};addr.sin_family=AF_INET;addr.sin_port=htons(static_cast<unsigned short>(port));addr.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
 if(bind(server,reinterpret_cast<sockaddr*>(&addr),sizeof(addr))!=0||listen(server,16)!=0)throw std::runtime_error("Cannot bind port (already in use?)");
 std::cout<<"AI Sana Challenge Hub: http://127.0.0.1:"<<port<<"\nOffline demo. Ctrl+C to stop.\n"<<std::flush;
 for(;;){Socket c=accept(server,nullptr,nullptr);
#ifdef _WIN32
 if(c==INVALID_SOCKET)continue;DWORD timeout=3000;setsockopt(c,SOL_SOCKET,SO_RCVTIMEO,reinterpret_cast<const char*>(&timeout),sizeof(timeout));setsockopt(c,SOL_SOCKET,SO_SNDTIMEO,reinterpret_cast<const char*>(&timeout),sizeof(timeout));
#else
 if(c<0)continue;
 timeval timeout{3,0};setsockopt(c,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));setsockopt(c,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof(timeout));
#endif
 Response res;try{std::string raw;char buf[8192];size_t end=std::string::npos;while((end=raw.find("\r\n\r\n"))==std::string::npos){int n=recv(c,buf,sizeof(buf),0);if(n<=0)throw std::runtime_error("Incomplete headers");raw.append(buf,n);if(raw.size()>65536)throw std::runtime_error("Headers too large");}
 Request req;std::istringstream head(raw.substr(0,end));head>>req.method>>req.path;std::string line;std::getline(head,line);while(std::getline(head,line)){auto x=line.find(':');if(x==std::string::npos)continue;std::string key=line.substr(0,x),val=line.substr(x+1);std::transform(key.begin(),key.end(),key.begin(),[](unsigned char a){return char(std::tolower(a));});while(!val.empty()&&std::isspace(static_cast<unsigned char>(val.front())))val.erase(0,1);while(!val.empty()&&std::isspace(static_cast<unsigned char>(val.back())))val.pop_back();req.headers[key]=val;}
 size_t length=0;if(req.headers.count("content-length")){size_t used=0;length=std::stoul(req.headers["content-length"],&used);if(used!=req.headers["content-length"].size())throw std::runtime_error("Invalid length");}if(length>131072)throw std::runtime_error("Body too large");req.body=raw.substr(end+4);while(req.body.size()<length){int n=recv(c,buf,sizeof(buf),0);if(n<=0)throw std::runtime_error("Incomplete body");req.body.append(buf,n);}req.body.resize(length);
 const auto host=req.headers["host"];const std::string allowed="127.0.0.1:"+std::to_string(port),local="localhost:"+std::to_string(port);
 if(host!=allowed&&host!=local)res=error(403,"Недопустимый адрес сервера");else if(req.method=="POST"&&req.headers.count("origin")&&req.headers["origin"]!="http://"+allowed&&req.headers["origin"]!="http://"+local)res=error(403,"Запрос с другого сайта запрещён");else res=handler(req);
 }catch(const std::exception&){res=error(400,"Не удалось обработать запрос. Проверьте данные и повторите.");}
 std::string msg="HTTP/1.1 "+std::to_string(res.status)+(res.status==200?" OK":" Error")+"\r\nContent-Type: "+res.type+"\r\nContent-Length: "+std::to_string(res.body.size())+"\r\nConnection: close\r\nX-Content-Type-Options: nosniff\r\nCache-Control: no-store\r\nContent-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'; base-uri 'none'\r\n\r\n"+res.body;sendAll(c,msg);closeSocket(c);}
}
}
