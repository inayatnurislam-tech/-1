#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
${CXX:-g++} -std=c++17 -O2 -Wall -Wextra -Wpedantic src/main.cpp -o sana
exec ./sana "${PORT:-8080}"
