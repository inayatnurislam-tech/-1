#include "../src/demo.hpp"
#include <cassert>
#include <iostream>
using namespace sana;
int main(){
 Fields f={{"description","Хотим уменьшить очереди в столовой"},{"result","Уменьшить время ожидания"},{"weeks","4"},{"industry","Образование"}};
 assert(readiness(f).total==28);assert(!publishable(f));
 auto full=seeds()[0];assert(readiness(full).total==91);assert(publishable(full));
 auto unknown=full;for(int i=0;i<8;i++)unknown["u"+std::to_string(i)]="1";assert(readiness(unknown).total<70);assert(!publishable(unknown));
 auto unsafe=full;unsafe["a4"]="Распознавание лиц";assert(!publishable(unsafe));
 auto shortTerm=full;shortTerm["a6"]="1";assert(!publishable(shortTerm));
 auto best=match(full,teams()[1]);assert(best.score==93);assert(match(full,teams()[4],true).score>match(full,teams()[4]).score);
 for(auto& t:teams()){auto m=match(full,t);assert(m.score>=0&&m.score<=100);}
 assert(quote("a\n\"b") == "\"a\\n\\\"b\"");
 std::cout<<"Model tests passed: readiness, assumptions, publication, safety, matching, JSON.\n";
}
