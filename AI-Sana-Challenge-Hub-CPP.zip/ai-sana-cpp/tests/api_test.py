"""Integration tests; standard-library Python only. Run after make."""
import json
import shutil
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PORT = 18081
BASE = f'http://127.0.0.1:{PORT}'

def request(path, fields=None, headers=None):
    body = urllib.parse.urlencode(fields).encode() if fields is not None else None
    req = urllib.request.Request(BASE + path, data=body, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.load(r)
    except urllib.error.HTTPError as e:
        return e.code, json.load(e)

def start(root):
    binary = ROOT / ('sana.exe' if __import__('os').name == 'nt' else 'sana')
    p = subprocess.Popen([str(binary), str(PORT), str(root)], stdout=subprocess.DEVNULL)
    for _ in range(50):
        try:
            request('/api/bootstrap')
            return p
        except (OSError, urllib.error.URLError):
            time.sleep(.05)
    p.terminate()
    raise RuntimeError('Server did not start')

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    shutil.copytree(ROOT / 'web', root / 'web')
    p = start(root)
    try:
        code, db = request('/api/bootstrap')
        assert code == 200 and len(db['challenges']) == 6
        full = db['challenges'][0].copy()
        full.pop('id')
        assert request('/api/publish', {'title': 'Incomplete'})[0] == 400
        for text in ['1', 'abc', '0', '53']:
            bad = dict(full, a6=text)
            assert request('/api/publish', bad)[0] in (400, 422)
        assert request('/api/publish', dict(full, a4='Распознавание лиц'))[0] == 422
        assert request('/api/publish', full, {'Origin': 'https://other.example'})[0] == 403
        code, added = request('/api/publish', full)
        assert code == 200 and added['id'].startswith('task-')
        id_ = added['id']
        for _ in range(2):
            assert request('/api/apply', {'id': id_, 'team': 'steppe'})[0] == 200
        assert request('/api/apply', {'id': id_, 'team': 'invalid'})[0] == 400
        added['title'] = 'Сохранённая правка'
        assert request('/api/publish', added)[0] == 200
        assert request('/data/challenges.db')[0] == 404
        p.terminate()
        p.wait(timeout=5)
        p = start(root)
        rows = request('/api/bootstrap')[1]['challenges']
        assert len(rows) == 7
        result = next(x for x in rows if x['id'] == id_)
        assert result['applications'] == 'steppe'
        assert result['title'] == 'Сохранённая правка'
        print('API tests passed: validation, publication, updates, applications, restart persistence, origin, private files.')
    finally:
        p.terminate()
        p.wait(timeout=5)
