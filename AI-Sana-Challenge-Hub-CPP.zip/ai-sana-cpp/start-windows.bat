@echo off
cd /d "%~dp0"
where g++ >nul 2>nul
if errorlevel 1 (
  echo Install a C++17 compiler such as MinGW-w64 and add g++ to PATH.
  pause
  exit /b 1
)
g++ -std=c++17 -O2 -Wall -Wextra -Wpedantic src/main.cpp -o sana.exe -lws2_32
if errorlevel 1 (
  pause
  exit /b 1
)
echo Open http://127.0.0.1:8080 in your browser.
sana.exe
pause
